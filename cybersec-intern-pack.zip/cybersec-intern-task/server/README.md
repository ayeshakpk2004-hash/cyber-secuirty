# User Management System (Secure Demo)

A minimal Node.js/Express app for cybersecurity interns to **find** and then **fix** common issues.
This version already includes basic hardening (Helmet, input validation, bcrypt, JWT, logging).
Use it to practice testing with OWASP ZAP, devtools, and basic penetration checks.

## Quick Start

```bash
cd server
npm install
cp .env.example .env
# (edit .env and change JWT_SECRET)
npm start
```

App runs at: `http://localhost:3000`

## Endpoints
- `GET /` - health check
- `POST /signup` - body: `{ email, password, name }`
- `POST /login` - body: `{ email, password }` -> returns `{ token }`
- `GET /profile` - header: `Authorization: Bearer <token>`

## Tools to Use
- **OWASP ZAP**: Run an automated scan against `http://localhost:3000`.
- **DevTools**: Try injecting `<script>alert('XSS');</script>` in fields (note: responses are JSON).
- **SQLi**: The app uses an in-memory Map (no SQL). Consider how you'd test if it used SQL, and list mitigations.
- **Nmap**: Scan localhost for open ports to understand exposure in multi-service setups.
