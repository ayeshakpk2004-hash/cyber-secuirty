# Submission Instructions

1. **Video Explanation**
   - Record your screen (5–10 min): assessment steps, fixes, and final checks.
2. **GitHub Repository**
   - Push this project to GitHub. Include your modified code and completed `REPORT_TEMPLATE.md` and `CHECKLIST.md`.
3. **Report Document**
   - Fill out `REPORT_TEMPLATE.md` and export to PDF if required.

## How to push to GitHub (quick)
```bash
git init
git add .
git commit -m "Cybersecurity task submission"
git branch -M main
git remote add origin https://github.com/<your-username>/cybersec-intern-task.git
git push -u origin main
```
